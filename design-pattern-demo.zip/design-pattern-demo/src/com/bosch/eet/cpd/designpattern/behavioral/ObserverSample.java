/*
 * Copyright (c) Robert Bosch GmbH. All rights reserved.
 */
package com.bosch.eet.cpd.designpattern.behavioral;

import java.util.ArrayList;
import java.util.List;

/**
 * @author PGN2HC
 *
 */
public class ObserverSample {

	// Step 5: Client code that uses the Observer pattern
	/**
	 * @param args args
	 */
	public static void main(String[] args) {
		// Create the subject (WeatherData)
		WhetherChannel weatherData = new WhetherChannel();

		// Create observers (displays)
		CurrentConditionsDisplay currentConditionsDisplay = new CurrentConditionsDisplay();

		// Register the observers with the subject
		weatherData.registerObserver(currentConditionsDisplay);

		// Simulate changes in weather conditions
		weatherData.setMeasurements(25.0f, 60.0f, 101.3f);
		weatherData.setMeasurements(28.5f, 55.0f, 100.2f);
	}

}

//Step 1: Define the subject (observable) interface
interface Subject {
	void registerObserver(Observer observer);

	void removeObserver(Observer observer);

	void notifyObservers();
}

//Step 2: Define the observer interface
interface Observer {
	void update(float temperature, float humidity, float pressure);
}

//Step 3: Create a concrete subject (WeatherData)
class WhetherChannel implements Subject {
	private List<Observer> observers;
	private float temperature;
	private float humidity;
	private float pressure;

	public WhetherChannel() {
		observers = new ArrayList<>();
	}

	@Override
	public void registerObserver(Observer observer) {
		observers.add(observer);
	}

	@Override
	public void removeObserver(Observer observer) {
		observers.remove(observer);
	}

	@Override
	public void notifyObservers() {
		for (Observer observer : observers) {
			observer.update(temperature, humidity, pressure);
		}
	}

	// Simulate a change in weather conditions
	public void measurementsChanged() {
		notifyObservers();
	}

	public void setMeasurements(float temperature, float humidity, float pressure) {
		this.temperature = temperature;
		this.humidity = humidity;
		this.pressure = pressure;
		measurementsChanged();
	}
}

//Step 4: Create concrete observer classes (Display) that implement the
//Observer interface
class CurrentConditionsDisplay implements Observer {
	private float temperature;
	private float humidity;

	@Override
	public void update(float temp, float humid, float pressure) {
		this.temperature = temp;
		this.humidity = humid;
		display();
	}

	public void display() {
		System.out.println("Current conditions: " + temperature + "�C and " + humidity + "% humidity");
	}

}
