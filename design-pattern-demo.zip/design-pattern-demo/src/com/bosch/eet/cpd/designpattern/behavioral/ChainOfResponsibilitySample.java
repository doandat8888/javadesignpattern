/*
 * Copyright (c) Robert Bosch GmbH. All rights reserved.
 */
package com.bosch.eet.cpd.designpattern.behavioral;

/**
 * @author PGN2HC
 *
 */
public class ChainOfResponsibilitySample {

	// Step 4: Client code that uses the Chain of Responsibility
	/**
	 * @param args args
	 */
	public static void main(String[] args) {
		// Create the handler chain
		SupportHandler level3Handler = new Level3SupportHandler();
		SupportHandler level2Handler = new Level2SupportHandler();
		SupportHandler level1Handler = new Level1SupportHandler();

		level1Handler.setNextHandler(level2Handler);
		level2Handler.setNextHandler(level3Handler);

		// Create tickets with different priorities
		Ticket ticket1 = new Ticket(Priority.LEVEL1, "Printer not working");
		Ticket ticket2 = new Ticket(Priority.LEVEL2, "Network connection issue");
		Ticket ticket3 = new Ticket(Priority.LEVEL3, "Software installation problem");

		// Submit tickets to the handler chain
		level1Handler.handleRequest(ticket1);
		level1Handler.handleRequest(ticket2);
		level1Handler.handleRequest(ticket3);
	}

}

//Step 1: Define the handler interface
interface SupportHandler {
	void handleRequest(Ticket ticket);

	void setNextHandler(SupportHandler nextHandler);
}

// Step 2: Create concrete handler classes
class Level1SupportHandler implements SupportHandler {
	private SupportHandler nextHandler;

	@Override
	public void handleRequest(Ticket ticket) {
		if (ticket.getPriority() == Priority.LEVEL1) {
			System.out.println("Level 1 support handles ticket: " + ticket.getDescription());
		} else if (nextHandler != null) {
			nextHandler.handleRequest(ticket);
		} else {
			System.out.println("No handler available for ticket: " + ticket.getDescription());
		}
	}

	@Override
	public void setNextHandler(SupportHandler nextHandler) {
		this.nextHandler = nextHandler;
	}
}

class Level2SupportHandler implements SupportHandler {
	private SupportHandler nextHandler;

	@Override
	public void handleRequest(Ticket ticket) {
		if (ticket.getPriority() == Priority.LEVEL2) {
			System.out.println("Level 2 support handles ticket: " + ticket.getDescription());
		} else if (nextHandler != null) {
			nextHandler.handleRequest(ticket);
		} else {
			System.out.println("No handler available for ticket: " + ticket.getDescription());
		}
	}

	@Override
	public void setNextHandler(SupportHandler nextHandler) {
		this.nextHandler = nextHandler;
	}
}

class Level3SupportHandler implements SupportHandler {
	@Override
	public void handleRequest(Ticket ticket) {
		if (ticket.getPriority() == Priority.LEVEL3) {
			System.out.println("Level 3 support handles ticket: " + ticket.getDescription());
		} else {
			System.out.println("No handler available for ticket: " + ticket.getDescription());
		}
	}

	@Override
	public void setNextHandler(SupportHandler nextHandler) {
		// Level 3 handler is the end of the chain; no next handler
	}
}

// Step 3: Create a class to represent the request (ticket)
enum Priority {
	LEVEL1, LEVEL2, LEVEL3
}

class Ticket {
	private final Priority priority;
	private final String description;

	public Ticket(Priority priority, String description) {
		this.priority = priority;
		this.description = description;
	}

	public Priority getPriority() {
		return priority;
	}

	public String getDescription() {
		return description;
	}
}
