/*
 * Copyright (c) Robert Bosch GmbH. All rights reserved.
 */
package com.bosch.eet.cpd.designpattern.creation;

/**
 * @author PGN2HC
 *
 */
public class SingletonSample {
	
	/**
	 * @param args args
	 */
	public static void main(String[] args) {
		SingletonObj.getInstance().printMessage();
	}
	
}

class SingletonObj {

	// private static SingletonObj singletonObj = new SingletonObj();
	private static SingletonObj singletonObj;

	private SingletonObj() {
	}

//	/**
//	 * @return early get instance
//	 */
//	public static SingletonObj getInstance() {
//		return singletonObj;
//	}

	/**
	 * @return lazy initialize instance
	 */
	public static synchronized SingletonObj getInstance() {
		if (singletonObj == null) {
			singletonObj = new SingletonObj();
		}
		return singletonObj;
	}

	/**
	 * 
	 */
	public void printMessage() {
		System.out.println("Hello EET Trainee!");
	}
	
}
