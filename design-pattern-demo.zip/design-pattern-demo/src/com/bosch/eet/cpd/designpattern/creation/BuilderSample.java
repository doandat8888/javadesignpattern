/*
 * Copyright (c) Robert Bosch GmbH. All rights reserved.
 */
package com.bosch.eet.cpd.designpattern.creation;

/**
 * @author PGN2HC
 *
 */
public class BuilderSample {

	/**
	 * @param args args
	 */
	public static void main(String[] args) {

		Product product = new Product.Builder("Sample Product", 100).build();
		System.out.println("Product #1");
		// Accessing the properties of the created Product
		System.out.println("Product Name: " + product.getName());
		System.out.println("Product Price: $" + product.getPrice());
		System.out.println("Product Description: " + product.getDescription());
		System.out.println("Product Discount: " + product.getDiscount());

		// Using the builder pattern to create a Product instance
		product = new Product.Builder("Sample Product", 100).description("This is a sample product description.")
				.build();
		System.out.println("Product #2 with description");
		// Accessing the properties of the created Product
		System.out.println("Product Name: " + product.getName());
		System.out.println("Product Price: $" + product.getPrice());
		System.out.println("Product Description: " + product.getDescription());
		System.out.println("Product Discount: " + product.getDiscount());

		product = new Product.Builder("Sample Product", 100).discount(10).build();
		System.out.println("Product #2 with description");
		// Accessing the properties of the created Product
		System.out.println("Product Name: " + product.getName());
		System.out.println("Product Price: $" + product.getPrice());
		System.out.println("Product Description: " + product.getDescription());
		System.out.println("Product Discount: " + product.getDiscount());
	}
}

class Product {
	private String name;
	private int price;
	private String description;
	private int discount;

	private Product(Builder builder) {
		this.name = builder.name;
		this.price = builder.price;
		this.description = builder.description;
		this.discount = builder.discount;
	}

	public String getName() {
		return name;
	}

	public int getPrice() {
		return price;
	}

	public String getDescription() {
		return description;
	}

	/**
	 * @return the discount
	 */
	public int getDiscount() {
		return discount;
	}

	public static class Builder {
		private String name;
		private int price;
		private String description;
		private int discount;

		public Builder(String name, int price) {
			this.name = name;
			this.price = price;
		}

		public Builder description(String des) {
			this.description = des;
			return this;
		}

		public Builder discount(int discount) {
			this.discount = discount;
			return this;
		}

		public Product build() {
			return new Product(this);
		}
	}
}
