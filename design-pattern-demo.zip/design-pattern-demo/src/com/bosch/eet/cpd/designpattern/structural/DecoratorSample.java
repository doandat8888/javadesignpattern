/*
 * Copyright (c) Robert Bosch GmbH. All rights reserved.
 */
package com.bosch.eet.cpd.designpattern.structural;

/**
 * @author PGN2HC
 *
 */
public class DecoratorSample {

	// Step 5: Client code that uses decorators to customize laptop requests
	/**
	 * @param args args
	 */
	public static void main(String[] args) {
		// Order a simple laptop
		Laptop laptop = new BasicLaptop();
		System.out.println("Cost: $" + laptop.cost());
		System.out.println("Description: " + laptop.description());

		// Order a laptop with high performance
		Laptop laptopWithHighResources = new PerformanceDecorator(new BasicLaptop());
		System.out.println("\nCost: $" + laptopWithHighResources.cost());
		System.out.println("Description: " + laptopWithHighResources.description());

		// Order a laptop with high performance and GPU
		Laptop laptopWithHighRamAndBestGpu = new GraphicsDecorator(new PerformanceDecorator(new BasicLaptop()));
		System.out.println("\nCost: $" + laptopWithHighRamAndBestGpu.cost());
		System.out.println("Description: " + laptopWithHighRamAndBestGpu.description());
	}

}

//Step 1: Create a base interface or abstract class for the laptop component
interface Laptop {
	double cost();

	String description();
}

// Step 2: Create a concrete laptop class (the base component)
class BasicLaptop implements Laptop {
	@Override
	public double cost() {
		return 1000.0; // Base cost of simple laptop
	}

	@Override
	public String description() {
		return "Simple Laptop";
	}
}

// Step 3: Create decorator classes that extend the base component
abstract class LaptopDecorator implements Laptop {
	private final Laptop decoratedLaptop;

	public LaptopDecorator(Laptop decoratedLaptop) {
		this.decoratedLaptop = decoratedLaptop;
	}

	@Override
	public double cost() {
		return decoratedLaptop.cost();
	}

	@Override
	public String description() {
		return decoratedLaptop.description();
	}
}

// Step 4: Create concrete decorator classes that add specific behaviors
class PerformanceDecorator extends LaptopDecorator {
	public PerformanceDecorator(Laptop decoratedLaptop) {
		super(decoratedLaptop);
	}

	@Override
	public double cost() {
		return super.cost() + 500.0; // Add the cost of milk
	}

	@Override
	public String description() {
		return super.description() + ", with '128GB Ram and Intel Core i7-13700K'";
	}
}

class GraphicsDecorator extends LaptopDecorator {
	public GraphicsDecorator(Laptop decoratedLaptop) {
		super(decoratedLaptop);
	}

	@Override
	public double cost() {
		return super.cost() + 1000.0; // Add the cost of sugar
	}

	@Override
	public String description() {
		return super.description() + ", with 'GIGABYTE AORUS GTX 1080 Ti Xtreme Edition 11G'";
	}
}
