/*
 * Copyright (c) Robert Bosch GmbH. All rights reserved.
 */
package com.bosch.eet.cpd.designpattern.creation;

/**
 * @author PGN2HC
 *
 */
public class FactorySample {

	// Step 5: Client code that uses the factory to create products
	/**
	 * @param args args
	 */
	public static void main(String[] args) {
		// Create a factory for Product A
		EngineFactory myFactory = new GasolineEngineFactory();
		// Create a factory for Product B
		// EngineFactory myFactory = new GasolineEngineFactory();

		CombustionEngine myEngineINeed = myFactory.createEngine();
		myEngineINeed.displayInfo();
	}
}

//Step 1: Create an interface for the product
interface CombustionEngine {
	void displayInfo();
}

// Step 2: Create concrete classes that implement the Product interface
class DieselEngine implements CombustionEngine {
	@Override
	public void displayInfo() {
		System.out.println("This is a Diesel engine");
	}
}

class GasolineEngine implements CombustionEngine {
	@Override
	public void displayInfo() {
		System.out.println("This is a Gasoline engine");
	}
}

// Step 3: Create a factory interface
interface EngineFactory {
	CombustionEngine createEngine();

}

// Step 4: Create concrete factory classes that implement the factory interface
class GasolineEngineFactory implements EngineFactory {
	@Override
	public CombustionEngine createEngine() {
		return new GasolineEngine();
	}
}

class DieselEngineFactory implements EngineFactory {
	@Override
	public CombustionEngine createEngine() {
		return new DieselEngine();
	}
}