/*
 * Copyright (c) Robert Bosch GmbH. All rights reserved.
 */
package com.bosch.eet.cpd.designpattern.structural;

/**
 * @author PGN2HC
 *
 */
public class AdapterSample {

	// Step 4: Client code that uses the Adapter
	/**
	 * @param args args
	 */
	public static void main(String[] args) {
		// Create a Celsius temperature
		Temperature celsiusTemperature = new CelsiusTemperature();
		celsiusTemperature.setTemperature(25);

		// Create a Fahrenheit temperature
		FahrenheitTemperature fahrenheitTemperature = new FahrenheitTemperature();
		fahrenheitTemperature.setTemperature(77);

		// Create an adapter to use the Fahrenheit temperature as if it were a Celsius
		// temperature
		Temperature adapter = new FahrenheitToCelsiusAdapter(fahrenheitTemperature);

		System.out.println("Celsius Temperature: " + celsiusTemperature.getTemperature() + " �C");
		System.out.println("Fahrenheit Temperature: " + fahrenheitTemperature.getTemperature() + " �F");
		System.out.println("Fahrenheit Temperature (converted to Celsius): " + adapter.getTemperature() + " �C");
	}

}

//Step 1: Create an interface that the client expects to work with
interface Temperature {
	double getTemperature();

	void setTemperature(double temperature);
}

// Step 2: Create concrete classes representing different temperature scales
class CelsiusTemperature implements Temperature {
	private double temperature;

	@Override
	public double getTemperature() {
		return temperature;
	}

	@Override
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
}

class FahrenheitTemperature {
	private double temperature;

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
}

// Step 3: Create an adapter class that implements the Temperature interface
class FahrenheitToCelsiusAdapter implements Temperature {
	private FahrenheitTemperature fahrenheitTemperature;

	public FahrenheitToCelsiusAdapter(FahrenheitTemperature fahrenheitTemperature) {
		this.fahrenheitTemperature = fahrenheitTemperature;
	}

	@Override
	public double getTemperature() {
		// Convert Fahrenheit to Celsius and return
		return (fahrenheitTemperature.getTemperature() - 32) * 5 / 9;
	}

	@Override
	public void setTemperature(double temperature) {
		// Convert Celsius to Fahrenheit and set
		fahrenheitTemperature.setTemperature((temperature * 9 / 5) + 32);
	}
}